package com.dyonovan.neotech.common;

public class CommonProxy {

    public void init() {

    }

}
