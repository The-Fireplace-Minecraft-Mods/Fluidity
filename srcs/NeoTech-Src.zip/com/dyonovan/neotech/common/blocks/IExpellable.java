package com.dyonovan.neotech.common.blocks;

public interface IExpellable {

    public void expelItems();
}
