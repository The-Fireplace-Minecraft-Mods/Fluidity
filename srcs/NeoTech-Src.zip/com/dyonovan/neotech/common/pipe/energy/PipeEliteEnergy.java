package com.dyonovan.neotech.common.pipe.energy;

public class PipeEliteEnergy extends PipeBasicEnergy {
    @Override
    public int getMaximumTransferRate() {
        return 5000;
    }
}
