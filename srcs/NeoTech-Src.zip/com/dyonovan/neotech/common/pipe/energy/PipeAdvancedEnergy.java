package com.dyonovan.neotech.common.pipe.energy;

public class PipeAdvancedEnergy extends PipeBasicEnergy {

    @Override
    public int getMaximumTransferRate() {
        return 100;
    }
}
