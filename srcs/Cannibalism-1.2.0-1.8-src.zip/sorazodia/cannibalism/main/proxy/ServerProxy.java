package sorazodia.cannibalism.main.proxy;

public class ServerProxy
{

	public void preInit()
	{
	}

	public void init()
	{
	}

}
