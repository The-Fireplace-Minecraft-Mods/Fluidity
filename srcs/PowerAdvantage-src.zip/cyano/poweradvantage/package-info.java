/**
This package contains the main mod class. If you are making an add-on mod, you probably want to use 
classes from the cyano.poweradvantage.api.simple package
*/
package cyano.poweradvantage;